# LAB READY™ — Infectious Diseases & Diagnostic Microbiology Reference (2026 Edition)

**Prepared by:** Dr. Elshahat Ahmed El Shahat, Assistant Professor of Microbiology  
**Standards Alignment:** CLSI M100 (36th Edition, 2026)  
**Platform:** Installable Progressive Web App (iOS, Android, Windows, macOS)

---

## Overview

**LAB READY™** is an offline-capable, point-of-care diagnostic microbiology and infectious diseases reference application designed for clinical microbiologists, infectious disease clinicians, pharmacists, medical laboratory scientists, and postgraduate researchers.

## Key Clinical & Laboratory Modules

1. **Syndrome-to-Etiology Differential Explorer:** Side-by-side bacterial, viral, fungal, and parasitic differential diagnoses across 6 major organ syndromes (CNS, Bloodstream/Sepsis, Lower Respiratory, Gastrointestinal, Urinary Tract, and Hepatobiliary) with mandatory specimen workups and red flags.
2. **13 Antibiotic Classes & Mechanisms:** Complete classification of antibacterial agents, spectrum of activity, mechanisms of action (Cell Wall, 30S/50S Ribosome, DNA Gyrase, Membrane Disruptors), and live search.
3. **Generic vs. Trade Names Directory:** Cross-searchable clinical index linking generic antibiotics to common international and regional brand names.
4. **CLSI 2026 Breakpoints & QC:** Interpretive disk diffusion (mm) and MIC (µg/mL) breakpoints aligned with **CLSI M100 (36th Ed., 2026)** alongside mandatory ATCC quality-control ranges.
5. **Clinical AST & Resistance Workflow:** Interactive diagnostic algorithm covering *Staphylococcus aureus* (MRSA, VISA, VRSA), coagulase-negative staphylococci (MR-CoNS), and *Enterobacterales* (ESBL-E).
6. **AMR Mechanisms Pathway:** Visual breakdown of the 6 core antimicrobial resistance mechanisms (enzymatic destruction, target modification, porin loss, efflux pumps, pathway bypass, and biofilms).
7. **Human Viruses & Antivirals:** DNA and RNA virus families, organ tropism, clinical diseases, and a 3-tier severity-based antiviral treatment roadmap.
8. **Human Fungi & Antifungals:** Yeasts, molds, and thermally dimorphic fungi with morphology filters, antifungal drug classes, and a 3-tier severity-based antifungal roadmap.
9. **Human Parasites & Antiparasitics:** Protozoa, nematodes, trematodes, and cestodes with transmission routes, diagnostic stages, and severity-stratified therapy.

---

## Local Development & Build

```bash
# 1. Install dependencies
npm install

# 2. Start local development server
npm run dev

# 3. Build production PWA bundle
npm run build
```

## Installing as a Native-Style App (PWA)

* **Windows / macOS (Chrome or Edge):** Open the deployed URL and click the **Install App** icon in the browser address bar or the app header.
* **Android (Chrome):** Tap **⋮ (Menu) → Install app / Add to Home screen**.
* **iPhone / iPad (Safari):** Tap **Share (□↑) → Add to Home Screen**.

© 2026 LAB READY™ | Understand the workflow. Master the concepts. Build laboratory confidence.

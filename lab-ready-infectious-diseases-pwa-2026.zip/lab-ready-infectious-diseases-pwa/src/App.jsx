import React, { useState, useMemo, useEffect } from 'react';
import {
  Search, ChevronDown, ChevronUp, ShieldCheck, FlaskConical,
  GitBranch, ArrowRight, CheckCircle2, AlertTriangle, BookOpen,
  Pill, Activity, Virus, Bug, Stethoscope, Download, Wifi, WifiOff,
  Smartphone, Monitor, X, Info, Sparkles, Layers
} from 'lucide-react';

// --- DATA DEFINITIONS ---

const ANTIBIOTIC_GROUPS = [
  {
    group: "Penicillins",
    moa: "Cell Wall Synthesis Inhibitor (PBPs)",
    spectrum: "Narrow to Extended-Spectrum",
    antibiotics: [
      { name: "Penicillin G / V", trade: "Pfizerpen, Veetids", description: "Natural penicillin; Streptococci, Treponema pallidum, susceptible anaerobes." },
      { name: "Ampicillin", trade: "Principen, Omnipen", description: "Aminopenicillin; Enterococcus faecalis, Listeria monocytogenes, susceptible Gram-negatives." },
      { name: "Amoxicillin", trade: "Amoxil, Moxatag", description: "Aminopenicillin with superior oral bioavailability; respiratory & ENT infections." },
      { name: "Oxacillin / Nafcillin", trade: "Bactocill, Nallpen", description: "Penicillinase-resistant anti-staphylococcal penicillins (MSSA)." },
      { name: "Piperacillin", trade: "Pipracil", description: "Extended-spectrum ureidopenicillin with potent anti-pseudomonal activity." },
      { name: "Ticarcillin", trade: "Ticar", description: "Carboxypenicillin with anti-pseudomonal activity." }
    ]
  },
  {
    group: "β-Lactam / β-Lactamase Inhibitor Combinations",
    moa: "Cell Wall Synthesis + β-Lactamase Inhibition",
    spectrum: "Broad-Spectrum (Aerobes & Anaerobes)",
    antibiotics: [
      { name: "Amoxicillin-Clavulanate", trade: "Augmentin", description: "Oral broad-spectrum coverage including β-lactamase-producing H. influenzae, M. catarrhalis, anaerobes." },
      { name: "Ampicillin-Sulbactam", trade: "Unasyn", description: "Parenteral coverage for polymicrobial intra-abdominal, skin/soft tissue, and Acinetobacter infections." },
      { name: "Piperacillin-Tazobactam", trade: "Zosyn, Tazocin", description: "Workhorse broad-spectrum anti-pseudomonal & anaerobic coverage for hospital sepsis." },
      { name: "Ceftazidime-Avibactam", trade: "Avycaz", description: "Activity against KPC, OXA-48 carbapenemase-producing Enterobacterales & MDR P. aeruginosa." },
      { name: "Meropenem-Vaborbactam", trade: "Vabomere", description: "Targeted therapy for KPC-producing carbapenem-resistant Enterobacterales (CRE)." }
    ]
  },
  {
    group: "Cephalosporins (1st – 5th Generations)",
    moa: "Cell Wall Synthesis Inhibitor (PBPs)",
    spectrum: "Generation-Dependent (Gram+ to Anti-MRSA/Anti-Pseudomonal)",
    antibiotics: [
      { name: "1st Gen: Cefazolin", trade: "Ancef, Kefzol", description: "Gold standard for MSSA bacteremia and surgical prophylaxis; strong Gram-positive activity." },
      { name: "2nd Gen: Cefuroxime", trade: "Zinacef, Ceftin", description: "Enhanced Gram-negative coverage (H. influenzae, M. catarrhalis) while retaining Gram-positive activity." },
      { name: "3rd Gen: Ceftriaxone", trade: "Rocephin", description: "Once-daily dosing, excellent CSF penetration (meningitis), gonorrhea, community pneumonia." },
      { name: "3rd Gen: Cefotaxime", trade: "Claforan", description: "Preferred 3rd-gen cephalosporin in neonates; excellent Gram-negative & CNS penetration." },
      { name: "3rd Gen: Ceftazidime", trade: "Fortaz, Tazicef", description: "Potent anti-pseudomonal 3rd-generation cephalosporin; weak Gram-positive activity." },
      { name: "4th Gen: Cefepime", trade: "Maxipime", description: "Broad-spectrum anti-pseudomonal; stable against AmpC β-lactamases; crosses BBB." },
      { name: "5th Gen: Ceftaroline", trade: "Teflaro", description: "Anti-MRSA cephalosporin (binds PBP2a) plus Gram-negative respiratory coverage." }
    ]
  },
  {
    group: "Carbapenems",
    moa: "Cell Wall Synthesis Inhibitor (Broadest β-Lactam)",
    spectrum: "Ultra-Broad (ESBL, AmpC, Anaerobes, P. aeruginosa)",
    antibiotics: [
      { name: "Meropenem", trade: "Merrem", description: "Broad-spectrum reserve agent; superior CNS penetration, lower seizure risk than imipenem." },
      { name: "Imipenem-Cilastatin", trade: "Primaxin", description: "Ultra-broad spectrum; cilastatin prevents renal dehydropeptidase-I inactivation." },
      { name: "Ertapenem", trade: "Invanz", description: "Once-daily dosing for ESBL Enterobacterales; lacks Pseudomonas and Acinetobacter activity." },
      { name: "Doripenem", trade: "Doribax", description: "Potent anti-pseudomonal carbapenem for complicated intra-abdominal and urinary infections." }
    ]
  },
  {
    group: "Aminoglycosides",
    moa: "30S Ribosomal Subunit Inhibitor (Bactericidal)",
    spectrum: "Aerobic Gram-Negative Bacilli & Gram-Positive Synergy",
    antibiotics: [
      { name: "Gentamicin", trade: "Garamycin", description: "Gram-negative sepsis & Enterococcal endocarditis synergy; monitor nephrotoxicity/ototoxicity." },
      { name: "Tobramycin", trade: "Nebcin, Tobi", description: "Superior activity against Pseudomonas aeruginosa; inhaled formulation for cystic fibrosis." },
      { name: "Amikacin", trade: "Amikin", description: "Most resistant to aminoglycoside-modifying enzymes; used for MDR Gram-negatives & NTM." },
      { name: "Streptomycin", trade: "Streptomycin", description: "Second-line Mycobacterium tuberculosis, tularemia, plague, and brucellosis." }
    ]
  },
  {
    group: "Fluoroquinolones",
    moa: "DNA Gyrase (Topoisomerase II) & Topoisomerase IV Inhibitor",
    spectrum: "Broad-Spectrum (Gram-Negative, Atypicals, Respiratory Gram+)",
    antibiotics: [
      { name: "Ciprofloxacin", trade: "Cipro", description: "Potent oral/IV Gram-negative & anti-pseudomonal coverage; weak S. pneumoniae activity." },
      { name: "Levofloxacin", trade: "Levaquin", description: "Respiratory fluoroquinolone (S. pneumoniae, Legionella, Mycoplasma) + Pseudomonas." },
      { name: "Moxifloxacin", trade: "Avelox", description: "Enhanced Gram-positive & anaerobic coverage; not active in urinary tract (hepatic clearance)." },
      { name: "Ofloxacin", trade: "Floxin", description: "2nd-generation quinolone for genitourinary and ophthalmic infections." }
    ]
  },
  {
    group: "Glycopeptides & Lipoglycopeptides",
    moa: "Cell Wall Synthesis Inhibitor (D-Ala-D-Ala Binding)",
    spectrum: "Gram-Positive Bacteria (MRSA, Enterococci, C. difficile)",
    antibiotics: [
      { name: "Vancomycin", trade: "Vancocin", description: "Primary IV therapy for MRSA; oral formulation (non-absorbed) for Clostridioides difficile." },
      { name: "Teicoplanin", trade: "Targocid", description: "Once-daily IM/IV glycopeptide with lower nephrotoxicity profile than vancomycin." },
      { name: "Dalbavancin", trade: "Dalvance", description: "Long-acting lipoglycopeptide (single weekly dose) for acute bacterial skin infections." }
    ]
  },
  {
    group: "Macrolides",
    moa: "50S Ribosomal Subunit Inhibitor (Translocation Block)",
    spectrum: "Atypical Pathogens, Gram-Positive Cocci, Spirochetes",
    antibiotics: [
      { name: "Azithromycin", trade: "Zithromax (Z-Pak)", description: "Long tissue half-life; Mycoplasma, Chlamydia, Legionella, Campylobacter, MAC prophylaxis." },
      { name: "Clarithromycin", trade: "Biaxin", description: "H. pylori eradication regimens, NTM/MAC therapy, and respiratory infections." },
      { name: "Erythromycin", trade: "Erythrocin", description: "Prototype macrolide; GI motilin agonist side effects; neonatal pertussis/chlamydia." }
    ]
  },
  {
    group: "Tetracyclines & Glycylcyclines",
    moa: "30S Ribosomal Subunit Inhibitor (Aminoacyl-tRNA Block)",
    spectrum: "Atypicals, Rickettsia, Spirochetes, MRSA, MDR Organisms",
    antibiotics: [
      { name: "Doxycycline", trade: "Vibramycin, Doryx", description: "Drug of choice for Rickettsia, Lyme disease, Chlamydia, Brucella, and outpatient MRSA." },
      { name: "Minocycline", trade: "Minocin", description: "High lipid solubility/CNS penetration; active against Acinetobacter baumannii & Nocardia." },
      { name: "Tetracycline", trade: "Sumycin", description: "Broad-spectrum; avoid in pregnancy and children <8 years (tooth enamel discoloration)." },
      { name: "Tigecycline", trade: "Tygacil", description: "Glycylcycline for MDR Enterobacterales, VRE, and MRSA; low serum levels (avoid in bacteremia)." }
    ]
  },
  {
    group: "Lincosamides",
    moa: "50S Ribosomal Subunit Inhibitor",
    spectrum: "Anaerobes & Gram-Positive Cocci (Toxin Suppression)",
    antibiotics: [
      { name: "Clindamycin", trade: "Cleocin", description: "Above-diaphragm anaerobes, CA-MRSA, and toxin suppression in necrotizing fasciitis/TSS; high C. diff risk." },
      { name: "Lincomycin", trade: "Lincocin", description: "Natural lincosamide with narrower spectrum and lower bioavailability than clindamycin." }
    ]
  },
  {
    group: "Polymyxins",
    moa: "Outer Cell Membrane Detergent / LPS Disruption",
    spectrum: "Last-Resort MDR Gram-Negative Bacilli",
    antibiotics: [
      { name: "Colistin (Polymyxin E)", trade: "Coly-Mycin M", description: "Salvage therapy for carbapenem-resistant Acinetobacter, Pseudomonas, and CRE; high nephrotoxicity." },
      { name: "Polymyxin B", trade: "Poly-Rx", description: "Active form administered IV (no renal prodrug conversion needed); topical ophthalmic/otic use." }
    ]
  },
  {
    group: "Nitroimidazoles",
    moa: "Free-Radical DNA Strand Breakage (Anaerobic Reduction)",
    spectrum: "Obligate Anaerobes & Protozoa",
    antibiotics: [
      { name: "Metronidazole", trade: "Flagyl", description: "Gold standard for Bacteroides fragilis, below-diaphragm anaerobes, Giardia, Trichomonas, Entamoeba." },
      { name: "Tinidazole", trade: "Tindamax", description: "Longer half-life nitroimidazole for protozoal infections and bacterial vaginosis." }
    ]
  },
  {
    group: "Oxazolidinones & Phenicols",
    moa: "50S Ribosomal Subunit Inhibitor",
    spectrum: "VRE, MRSA, MDR Gram-Positives & Broad-Spectrum",
    antibiotics: [
      { name: "Linezolid", trade: "Zyvox", description: "100% oral bioavailability; VRE and MRSA pneumonia/skin infections; monitor thrombocytopenia & serotonin syndrome." },
      { name: "Chloramphenicol", trade: "Chloromycetin", description: "Broad-spectrum CNS penetration; reserved due to dose-related marrow suppression and aplastic anemia." }
    ]
  }
];

const CLSI_2026_BREAKPOINTS = [
  {
    organism: "Staphylococcus aureus",
    agent: "Cefoxitin (30 µg disk / MIC)",
    susceptible: "≥ 22 mm (≤ 4 µg/mL)",
    intermediate: "—",
    resistant: "≤ 21 mm (≥ 8 µg/mL)",
    clinicalNote: "Surrogate marker for mecA/mecC-mediated methicillin resistance (MRSA). Report oxacillin/all β-lactams (except ceftaroline) as Resistant."
  },
  {
    organism: "Staphylococcus aureus",
    agent: "Vancomycin (Broth Microdilution MIC)",
    susceptible: "≤ 2 µg/mL",
    intermediate: "4 – 8 µg/mL (VISA)",
    resistant: "≥ 16 µg/mL (VRSA)",
    clinicalNote: "Disk diffusion is NOT valid for vancomycin in Staphylococci. Validate MIC ≥ 4 µg/mL immediately and notify public health."
  },
  {
    organism: "Staphylococcus lugdunensis",
    agent: "Cefoxitin (30 µg disk / MIC)",
    susceptible: "≥ 22 mm (≤ 4 µg/mL)",
    intermediate: "—",
    resistant: "≤ 21 mm (≥ 8 µg/mL)",
    clinicalNote: "CLSI M100 (2026) applies S. aureus cefoxitin breakpoints to S. lugdunensis (unlike other CoNS which use ≤ 24 mm / ≥ 25 mm)."
  },
  {
    organism: "Enterobacterales",
    agent: "Ceftriaxone (30 µg disk / MIC)",
    susceptible: "≥ 23 mm (≤ 1 µg/mL)",
    intermediate: "20 – 22 mm (2 µg/mL)",
    resistant: "≤ 19 mm (≥ 4 µg/mL)",
    clinicalNote: "MIC ≥ 2 µg/mL suggests ESBL or AmpC production; report susceptibility directly per CLSI 2026 breakpoints without editing."
  },
  {
    organism: "Enterobacterales",
    agent: "Meropenem (10 µg disk / MIC)",
    susceptible: "≥ 23 mm (≤ 1 µg/mL)",
    intermediate: "20 – 22 mm (2 µg/mL)",
    resistant: "≤ 19 mm (≥ 4 µg/mL)",
    clinicalNote: "Perform carbapenemase testing (mCIM/eCIM or molecular) on isolates with meropenem MIC ≥ 2 µg/mL for infection control & targeted therapy."
  },
  {
    organism: "Pseudomonas aeruginosa",
    agent: "Piperacillin-Tazobactam (100/10 µg)",
    susceptible: "≥ 22 mm (≤ 16/4 µg/mL)",
    intermediate: "15 – 21 mm (32/4 – 64/4 µg/mL)",
    resistant: "≤ 14 mm (≥ 128/4 µg/mL)",
    clinicalNote: "Intermediate category reflects higher-dose/extended-infusion dosing regimens per CLSI M100 36th Ed. (2026)."
  }
];

const CLSI_QC_STRAINS = [
  { strain: "Escherichia coli ATCC 25922", purpose: "Routine Gram-negative disk diffusion & MIC QC (β-lactams, aminoglycosides, quinolones)" },
  { strain: "Staphylococcus aureus ATCC 25923", purpose: "Routine Gram-positive disk diffusion QC (cefoxitin, clindamycin, erythromycin)" },
  { strain: "Staphylococcus aureus ATCC 29213", purpose: "Routine Gram-positive MIC broth microdilution QC (vancomycin, oxacillin, daptomycin)" },
  { strain: "Pseudomonas aeruginosa ATCC 27853", purpose: "Anti-pseudomonal β-lactam, carbapenem, and aminoglycoside cation-adjusted QC" },
  { strain: "Klebsiella pneumoniae ATCC 700603", purpose: "ESBL positive control strain (SHV-18) for β-lactam/β-lactamase inhibitor validation" }
];

const VIRUS_DATA = [
  {
    name: "Herpes Simplex Virus (HSV-1 / HSV-2)",
    family: "Herpesviridae",
    genome: "dsDNA (Enveloped)",
    organs: "Mucocutaneous epithelium, sensory ganglia, CNS (temporal lobe)",
    diseases: "Gingivostomatitis, herpes labialis, genital herpes, HSV encephalitis, neonatal HSV",
    treatments: {
      mild: "Oral Acyclovir, Valacyclovir, or Famciclovir (5–10 days)",
      moderate: "High-dose oral Valacyclovir or IV Acyclovir (5 mg/kg q8h) for severe mucocutaneous disease",
      severe: "IV Acyclovir 10 mg/kg q8h for 14–21 days (encephalitis/disseminated); IV Foscarnet if TK-mutant resistant"
    }
  },
  {
    name: "Cytomegalovirus (CMV / HHV-5)",
    family: "Herpesviridae",
    genome: "dsDNA (Enveloped)",
    organs: "Retina, GI tract, lungs, bone marrow, vascular endothelium",
    diseases: "CMV retinitis, pneumonitis, colitis (transplant/HIV), congenital CMV syndrome",
    treatments: {
      mild: "Immunocompetent mononucleosis: Supportive care (no antiviral required)",
      moderate: "Oral Valganciclovir 900 mg BID (induction) followed by 900 mg daily (maintenance)",
      severe: "IV Ganciclovir 5 mg/kg q12h; IV Foscarnet or Maribavir for UL97/UL54 ganciclovir-resistant strains"
    }
  },
  {
    name: "Hepatitis B Virus (HBV)",
    family: "Hepadnaviridae",
    genome: "Partially dsDNA (Reverse Transcriptase)",
    organs: "Hepatocytes (Liver)",
    diseases: "Acute & chronic hepatitis B, cirrhosis, hepatocellular carcinoma (HCC)",
    treatments: {
      mild: "Acute uncomplicated HBV: Supportive monitoring (>95% adult spontaneous clearance)",
      moderate: "Chronic HBV (elevated ALT/HBV DNA): Oral Entecavir 0.5 mg daily or Tenofovir Alafenamide (TAF) 25 mg daily",
      severe: "Decompensated cirrhosis / acute liver failure: Immediate Entecavir or Tenofovir DF + liver transplant evaluation"
    }
  },
  {
    name: "Influenza A & B Viruses",
    family: "Orthomyxoviridae",
    genome: "Segmented (-)ssRNA",
    organs: "Upper & lower respiratory tract ciliated epithelium",
    diseases: "Seasonal influenza, viral pneumonia, secondary bacterial pneumonia (S. aureus, S. pneumoniae)",
    treatments: {
      mild: "Outpatient (<48h onset): Oral Oseltamivir 75 mg BID x 5d or single-dose oral Baloxavir marboxil",
      moderate: "High-risk / hospitalized: Oral/NG Oseltamivir 75 mg BID (effective even >48h post-onset)",
      severe: "ICU / ARDS / intubated: Oseltamivir (enteral) or IV Peramivir + empiric antibacterial coverage for secondary pneumonia"
    }
  },
  {
    name: "SARS-CoV-2",
    family: "Coronaviridae",
    genome: "(+)ssRNA (Enveloped)",
    organs: "Respiratory epithelium (ACE2), vascular endothelium, myocardium",
    diseases: "COVID-19, viral pneumonia, ARDS, thromboembolism, multisystem inflammatory syndrome",
    treatments: {
      mild: "High-risk outpatient: Oral Nirmatrelvir-Ritonavir (Paxlovid) x 5d or IV Remdesivir x 3d",
      moderate: "Hospitalized requiring supplemental O2: IV Remdesivir (5 days) + Dexamethasone 6 mg daily",
      severe: "High-flow O2 / mechanical ventilation: Dexamethasone + Baricitinib or Tocilizumab + thromboprophylaxis"
    }
  },
  {
    name: "Human Immunodeficiency Virus (HIV-1 / HIV-2)",
    family: "Retroviridae",
    genome: "Diploid (+)ssRNA (Retrovirus)",
    organs: "CD4+ T-lymphocytes, macrophages, dendritic cells, CNS microglia",
    diseases: "Acute retroviral syndrome, progressive immunodeficiency, AIDS-defining opportunistic infections",
    treatments: {
      mild: "Asymptomatic / newly diagnosed: Immediate initiation of 1-pill daily integrase-based ART (Bictegravir/TAF/FTC or Dolutegravir-based)",
      moderate: "CD4 <200 cells/µL: ART initiation + TMP-SMX prophylaxis against Pneumocystis jirovecii",
      severe: "Advanced AIDS with opportunistic infection: Treat OI first (e.g., Cryptococcus/TB) then start ART within 2 weeks to prevent IRIS"
    }
  },
  {
    name: "Hepatitis C Virus (HCV)",
    family: "Flaviviridae",
    genome: "(+)ssRNA (Enveloped)",
    organs: "Hepatocytes (Liver)",
    diseases: "Chronic hepatitis C, hepatic fibrosis/cirrhosis, mixed cryoglobulinemia, HCC",
    treatments: {
      mild: "Acute HCV: Monitor 4–12 weeks or initiate pan-genotypic Direct-Acting Antivirals (DAAs)",
      moderate: "Chronic HCV without cirrhosis: Oral Glecaprevir/Pibrentasvir (8 wks) or Sofosbuvir/Velpatasvir (12 wks)",
      severe: "Decompensated cirrhosis (Child-Pugh B/C): Sofosbuvir/Velpatasvir + Ribavirin (avoid protease inhibitors)"
    }
  }
];

const FUNGAL_DATA = [
  {
    name: "Candida albicans & Non-albicans spp.",
    morphology: "Yeast / Pseudohyphae",
    organs: "Oropharynx, esophagus, vaginal mucosa, bloodstream, indwelling catheters",
    diseases: "Oral thrush, vulvovaginal candidiasis, candidemia, invasive candidiasis, endophthalmitis",
    treatments: {
      mild: "Mucocutaneous: Topical Clotrimazole/Nystatin or oral Fluconazole 150–200 mg",
      moderate: "Esophageal candidiasis: Oral or IV Fluconazole 200–400 mg daily for 14–21 days",
      severe: "Candidemia / ICU invasive disease: IV Echinocandin (Caspofungin, Micafungin, or Anidulafungin) + CVC removal"
    }
  },
  {
    name: "Candida auris",
    morphology: "Yeast (Multidrug-Resistant)",
    organs: "Bloodstream, wounds, ear canal, skin colonization (nosocomial)",
    diseases: "Healthcare-associated invasive candidemia, wound & device infections (high mortality)",
    treatments: {
      mild: "Asymptomatic skin colonization: Strict contact isolation & chlorhexidine decolonization (no systemic antifungal)",
      moderate: "Non-invasive urinary/wound infection: Guided strictly by antifungal susceptibility testing (AFST)",
      severe: "Invasive candidemia: IV Echinocandin first-line; Liposomal Amphotericin B if pan-echinocandin resistant"
    }
  },
  {
    name: "Cryptococcus neoformans / C. gattii",
    morphology: "Encapsulated Yeast (India Ink / CrAg+)",
    organs: "Lungs (inhalation) → Central Nervous System (Meninges)",
    diseases: "Cryptococcal meningoencephalitis, pulmonary cryptococcosis",
    treatments: {
      mild: "Isolated mild pulmonary disease (immunocompetent): Oral Fluconazole 400 mg daily for 6–12 months",
      moderate: "Moderate pulmonary / non-CNS disease: Fluconazole 400–800 mg daily; rule out CNS involvement via LP",
      severe: "Cryptococcal meningitis: Liposomal Amphotericin B + Flucytosine (induction), serial LPs for ICP, then Fluconazole consolidation"
    }
  },
  {
    name: "Aspergillus fumigatus",
    morphology: "Mold (Septate 45° Dichotomous Hyphae)",
    organs: "Sinuses, lungs, angioinvasion to brain/heart",
    diseases: "Allergic bronchopulmonary aspergillosis (ABPA), aspergilloma, invasive pulmonary aspergillosis (IPA)",
    treatments: {
      mild: "ABPA: Oral Itraconazole or Voriconazole + systemic corticosteroids",
      moderate: "Chronic pulmonary aspergillosis: Long-term oral Voriconazole or Itraconazole with Therapeutic Drug Monitoring (TDM)",
      severe: "Invasive Aspergillosis: IV/Oral Voriconazole or Isavuconazole first-line; Liposomal Amphotericin B as salvage"
    }
  },
  {
    name: "Mucorales (Rhizopus, Mucor, Lichtheimia)",
    morphology: "Mold (Broad Ribbon-Like Aseptate 90° Hyphae)",
    organs: "Paranasal sinuses, orbit, brain (rhinocerebral), lungs (angioinvasive necrosis)",
    diseases: "Rhinocerebral & pulmonary mucormycosis (DKA, neutropenia, iron overload)",
    treatments: {
      mild: "Localized cutaneous post-traumatic: Surgical debridement + oral Posaconazole",
      moderate: "Subacute sinus involvement: Immediate surgical debridement + Liposomal Amphotericin B",
      severe: "Rhinocerebral / Disseminated Mucormycosis: Urgent radical surgical debridement + high-dose IV Liposomal Amphotericin B + reversal of DKA/immunosuppression"
    }
  },
  {
    name: "Histoplasma capsulatum",
    morphology: "Thermally Dimorphic (Mold at 25°C / Intracellular Yeast at 37°C)",
    organs: "Lungs, reticuloendothelial system (liver, spleen, bone marrow)",
    diseases: "Acute/chronic pulmonary histoplasmosis, progressive disseminated histoplasmosis",
    treatments: {
      mild: "Acute mild pulmonary (<4 weeks): Observation / supportive care",
      moderate: "Moderate-to-chronic pulmonary: Oral Itraconazole (with TDM) for 6–12 weeks (or 12–24 months if chronic cavitary)",
      severe: "Progressive disseminated / CNS histoplasmosis: IV Liposomal Amphotericin B (1–2 weeks) followed by oral Itraconazole for ≥12 months"
    }
  }
];

const PARASITE_DATA = [
  {
    name: "Plasmodium falciparum / P. vivax",
    category: "Protozoa (Sporozoa)",
    transmission: "Female Anopheles mosquito bite",
    diagnosticStage: "Ring-form trophozoites, banana-shaped gametocytes (P. falciparum) on thick/thin blood smears",
    organs: "Hepatocytes (exo-erythrocytic) & Erythrocytes (microvascular sequestration)",
    diseases: "Malaria, cerebral malaria, severe hemolytic anemia, blackwater fever",
    treatments: {
      mild: "Uncomplicated chloroquine-resistant P. falciparum: Oral Artemether-Lumefantrine or Atovaquone-Proguanil (+ Primaquine for P. vivax hypnozoites after G6PD check)",
      moderate: "High parasitemia (>2%) without organ failure: Hospital admission + Artemisinin-based combination therapy (ACT)",
      severe: "Severe / Cerebral Malaria: Immediate IV Artesunate (2.4 mg/kg at 0, 12, 24h) + ICU glucose & organ support"
    }
  },
  {
    name: "Entamoeba histolytica",
    category: "Protozoa (Amoeba)",
    transmission: "Fecal-oral ingestion of mature quadrinucleate cysts",
    diagnosticStage: "Trophozoites with ingested RBCs (hematophagous) or 4-nuclei cysts in stool / ELISA",
    organs: "Colon (flask-shaped ulcers) & Liver (right lobe amoebic abscess)",
    diseases: "Amoebic dysentery, fulminant amoebic colitis, amoebic liver abscess",
    treatments: {
      mild: "Asymptomatic cyst passer: Luminal agent only (Paromomycin or Iodoquinol) to eradicate cysts",
      moderate: "Amoebic colitis / dysentery: Oral Metronidazole 500–750 mg TID x 7–10d FOLLOWED BY luminal Paromomycin",
      severe: "Amoebic liver abscess / toxic megacolon: IV Metronidazole + luminal agent; image-guided drainage if imminent rupture"
    }
  },
  {
    name: "Giardia duodenalis (lamblia)",
    category: "Protozoa (Flagellate)",
    transmission: "Fecal-oral ingestion of cysts (contaminated water/campers)",
    diagnosticStage: "Binucleate pear-shaped trophozoites ('falling leaf' motility) or oval cysts; stool antigen EIA",
    organs: "Duodenum and proximal jejunum (brush-border attachment)",
    diseases: "Giardiasis, foul-smelling steatorrhea, malabsorption, bloating",
    treatments: {
      mild: "Uncomplicated giardiasis: Single-dose oral Tinidazole 2 g or Nitazoxanide 500 mg BID x 3 days",
      moderate: "Persistent / recurrent symptoms: Oral Metronidazole 250 mg TID for 5–7 days",
      severe: "Refractory / hypogammaglobulinemia: Combination Tinidazole + Albendazole or Quinacrine + hydration"
    }
  },
  {
    name: "Strongyloides stercoralis",
    category: "Helminth (Nematode)",
    transmission: "Filariform larvae penetrating intact skin from soil; autoinfection cycle",
    diagnosticStage: "Rhabditiform larvae in stool (Baermann concentration) or serology",
    organs: "Small intestine mucosa, lungs (Löffler migration), disseminated organs in hyperinfection",
    diseases: "Strongyloidiasis, larva currens, fatal hyperinfection syndrome (with corticosteroids/HTLV-1)",
    treatments: {
      mild: "Uncomplicated intestinal infection: Oral Ivermectin 200 µg/kg daily for 2 consecutive days",
      moderate: "Chronic autoinfection / eosinophilia: Ivermectin 200 µg/kg repeated at 2 weeks",
      severe: "Hyperinfection / Disseminated Strongyloidiasis: Daily Ivermectin until stool/sputum negative ≥2 weeks + Gram-negative sepsis coverage + taper steroids"
    }
  },
  {
    name: "Schistosoma mansoni / S. haematobium",
    category: "Helminth (Trematode / Blood Fluke)",
    transmission: "Cercariae penetrating skin in freshwater containing Biomphalaria/Bulinus snails",
    diagnosticStage: "Lateral-spined eggs in stool (S. mansoni) or terminal-spined eggs in urine (S. haematobium)",
    organs: "Mesenteric venules/portal liver (S. mansoni) or vesical venous plexus/bladder (S. haematobium)",
    diseases: "Intestinal/hepatosplenic schistosomiasis (Symmers pipestem fibrosis), urinary schistosomiasis, squamous bladder carcinoma",
    treatments: {
      mild: "Acute Katayama fever: Corticosteroids for hypersensitivity followed by Praziquantel once adult worms mature",
      moderate: "Chronic intestinal or urinary schistosomiasis: Oral Praziquantel 40–60 mg/kg in divided doses for 1 day",
      severe: "Hepatosplenic portal hypertension / neuroschistosomiasis: Praziquantel + corticosteroids + endoscopic variceal management"
    }
  },
  {
    name: "Taenia solium (Neurocysticercosis)",
    category: "Helminth (Cestode / Tapeworm)",
    transmission: "Ingestion of T. solium eggs (fecal-oral) causes cysticercosis; undercooked pork causes taeniasis",
    diagnosticStage: "Brain MRI/CT showing vesicular/calcified cysticerci with scolex + EITB serology",
    organs: "Central Nervous System (brain parenchyma, ventricles, subarachnoid space), eye, skeletal muscle",
    diseases: "Neurocysticercosis (leading infectious cause of adult-onset epilepsy worldwide)",
    treatments: {
      mild: "Intestinal taeniasis (adult tapeworm only): Single-dose oral Praziquantel 5–10 mg/kg or Niclosamide",
      moderate: "1–2 viable parenchymal brain cysts: Albendazole 15 mg/kg/day x 10–14d + Dexamethasone + antiepileptic therapy",
      severe: ">2 viable cysts / subarachnoid / hydrocephalus: Albendazole + Praziquantel + high-dose steroids (ALWAYS rule out ocular cyst & hydrocephalus first)"
    }
  }
];

const SYNDROME_EXPLORER_DATA = [
  {
    id: "cns",
    title: "CNS: Acute Meningitis & Encephalitis",
    workup: "STAT Blood cultures x2, Lumbar Puncture (opening pressure, cell count, glucose, protein, Gram stain, CSF culture, BioFire FilmArray ME multiplex PCR), Brain CT prior to LP if focal deficits/papilledema.",
    redFlags: "Petechial/purpuric rash (N. meningitidis), altered mental status, temporal lobe hemorrhage (HSV-1), cranial nerve palsies.",
    empiric: "Vancomycin + Ceftriaxone (2g IV q12h) + Ampicillin (if age >50, neonate, or immunocompromised for Listeria) + IV Acyclovir + Dexamethasone.",
    etiologies: {
      bacterial: ["Streptococcus pneumoniae", "Neisseria meningitidis", "Listeria monocytogenes", "Streptococcus agalactiae (Group B Strep in neonates)"],
      viral: ["Herpes Simplex Virus (HSV-1 / HSV-2)", "Enteroviruses (Coxsackie, Echovirus)", "Varicella-Zoster Virus (VZV)", "West Nile Virus"],
      fungal: ["Cryptococcus neoformans / C. gattii (HIV/transplant)", "Coccidioides immitis", "Histoplasma capsulatum"],
      parasitic: ["Naegleria fowleri (primary amoebic meningoencephalitis)", "Toxoplasma gondii (ring-enhancing lesions)", "Taenia solium (neurocysticercosis)"]
    }
  },
  {
    id: "bloodstream",
    title: "Bloodstream: Sepsis & Infective Endocarditis",
    workup: "2–3 sets of aerobic/anaerobic blood cultures (20 mL/set) from separate venipunctures BEFORE antibiotics, serum lactate, procalcitonin, Transthoracic/Transesophageal Echocardiogram (TTE/TEE).",
    redFlags: "Septic shock (MAP <65 mmHg), new regurgitant heart murmur, Osler nodes, Janeway lesions, Roth spots, septic pulmonary emboli.",
    empiric: "Septic shock: Vancomycin + Cefepime or Piperacillin-Tazobactam (or Meropenem if ESBL risk) within 1 hour of recognition.",
    etiologies: {
      bacterial: ["Staphylococcus aureus (MSSA / MRSA)", "Escherichia coli & Klebsiella pneumoniae", "Viridans group Streptococci & Enterococcus faecalis", "Pseudomonas aeruginosa"],
      viral: ["Cytomegalovirus (CMV viremia in transplant)", "Epstein-Barr Virus (EBV)", "Dengue & viral hemorrhagic fevers"],
      fungal: ["Candida albicans & Candida glabrata", "Candida auris (ICU/central line)", "Histoplasma capsulatum (culture-negative endocarditis)"],
      parasitic: ["Plasmodium falciparum (severe malaria)", "Babesia microti (hemolytic anemia)", "Leishmania donovani (visceral kala-azar)"]
    }
  },
  {
    id: "respiratory",
    title: "Lower Respiratory: Community & Hospital Pneumonia",
    workup: "Sputum Gram stain & culture (<10 squamous epithelial cells, >25 PMNs/LPF), Blood cultures (severe CAP/HAP), Urine Legionella & S. pneumoniae antigens, Nasopharyngeal multiplex PCR.",
    redFlags: "Hypoxemia (SpO2 <90%), multilobar infiltrates, necrotizing cavitation (CA-MRSA/Klebsiella), hemoptysis, neutropenic halo sign.",
    empiric: "Inpatient CAP: Ceftriaxone + Azithromycin (or Levofloxacin monotherapy). HAP/VAP: Cefepime or Pip-Tazo + Vancomycin/Linezolid.",
    etiologies: {
      bacterial: ["Streptococcus pneumoniae", "Mycoplasma pneumoniae & Legionella pneumophila", "Staphylococcus aureus (MRSA) & Pseudomonas aeruginosa (HAP/VAP)", "Mycobacterium tuberculosis"],
      viral: ["Influenza A / B", "SARS-CoV-2", "Respiratory Syncytial Virus (RSV)", "Adenovirus"],
      fungal: ["Aspergillus fumigatus (invasive in neutropenia)", "Pneumocystis jirovecii (PCP in HIV CD4 <200)", "Cryptococcus & Histoplasma"],
      parasitic: ["Strongyloides stercoralis (hyperinfection pneumonitis)", "Paragonimus westermani (lung fluke)", "Ascaris lumbricoides (Löffler syndrome)"]
    }
  },
  {
    id: "gi",
    title: "Gastrointestinal: Infectious Diarrhea & Dysentery",
    workup: "Stool multiplex PCR panel, Stool culture (MacConkey/XLD/Campylobacter media), Clostridioides difficile GDH + Toxin A/B EIA or NAAT, Ova & Parasites (3 specimens).",
    redFlags: "Bloody diarrhea/dysentery, fever >38.5°C, severe dehydration, recent antibiotic exposure (C. diff), hemolytic uremic syndrome (STEC O157:H7).",
    empiric: "Rehydration is cornerstone. Avoid antibiotics in suspected STEC O157:H7 (HUS risk). Severe inflammatory diarrhea: Azithromycin or Ciprofloxacin.",
    etiologies: {
      bacterial: ["Campylobacter jejuni & Salmonella enterica", "Shigella spp. & Shiga toxin-producing E. coli (STEC)", "Clostridioides difficile (antibiotic-associated)", "Vibrio cholerae"],
      viral: ["Norovirus (leading adult outbreak cause)", "Rotavirus (pediatric watery diarrhea)", "Enteric Adenovirus (types 40/41)"],
      fungal: ["Candida spp. (esophagitis/immunocompromised)", "Histoplasma capsulatum (GI ulceration in AIDS)"],
      parasitic: ["Giardia duodenalis", "Entamoeba histolytica (amoebic dysentery)", "Cryptosporidium parvum (watery diarrhea in HIV)"]
    }
  },
  {
    id: "uti",
    title: "Urinary Tract: Complicated UTI & Pyelonephritis",
    workup: "Clean-catch midstream or straight-catheter urine dipstick (nitrite/leukocyte esterase), urine microscopy, quantitative urine culture (≥10⁵ CFU/mL), blood cultures if febrile/pyelonephritis.",
    redFlags: "Costovertebral angle (CVA) tenderness, high fever/rigors, obstructive uropathy/hydronephrosis (urologic emergency), emphysematous pyelonephritis.",
    empiric: "Uncomplicated cystitis: Nitrofurantoin or TMP-SMX. Pyelonephritis: IV Ceftriaxone (or Ertapenem/Meropenem if prior ESBL history).",
    etiologies: {
      bacterial: ["Escherichia coli (UPEC — 75–85% of cases)", "Klebsiella pneumoniae & Proteus mirabilis (struvite stones)", "Enterococcus faecalis & Staphylococcus saprophyticus", "Pseudomonas aeruginosa (catheter-associated)"],
      viral: ["BK Polyomavirus (hemorrhagic cystitis in transplant)", "Adenovirus (pediatric hemorrhagic cystitis)"],
      fungal: ["Candida albicans & Candida glabrata (catheterized/diabetic candiduria)"],
      parasitic: ["Schistosoma haematobium (terminal hematuria, bladder calcification)", "Trichomonas vaginalis (urethritis/vaginitis)"]
    }
  },
  {
    id: "hepatobiliary",
    title: "Hepatobiliary: Acute Hepatitis & Liver Abscess",
    workup: "Liver panel (AST, ALT, ALP, bilirubin, INR), Viral hepatitis serologies (HAV IgM, HBsAg, HBc IgM, HCV Ab + HCV RNA), RUQ Ultrasound/CT abdomen, blood cultures.",
    redFlags: "Hepatic encephalopathy, INR ≥1.5 (acute liver failure), Charcot triad / Reynolds pentad (ascending cholangitis), solitary right-lobe abscess.",
    empiric: "Viral hepatitis: Supportive + targeted antivirals (Entecavir/Tenofovir for severe HBV). Pyogenic liver abscess: Ceftriaxone + Metronidazole + drainage.",
    etiologies: {
      bacterial: ["Klebsiella pneumoniae (hypervirulent pyogenic abscess) & E. coli", "Bacteroides fragilis & Streptococcus anginosus group", "Leptospira interrogans (Weil disease)"],
      viral: ["Hepatitis A Virus (HAV) & Hepatitis E Virus (HEV)", "Hepatitis B Virus (HBV) & Hepatitis D (HDV)", "Hepatitis C Virus (HCV)", "Epstein-Barr Virus (EBV) & CMV"],
      fungal: ["Candida spp. (hepatosplenic candidiasis post-neutropenia recovery)"],
      parasitic: ["Entamoeba histolytica (amoebic 'anchovy paste' liver abscess)", "Echinococcus granulosus (hydatid liver cyst)", "Fasciola hepatica (liver fluke)"]
    }
  }
];

// --- MAIN APPLICATION COMPONENT ---

export default function App() {
  const [activeTab, setActiveTab] = useState('syndrome');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedGroups, setExpandedGroups] = useState({ "Penicillins": true, "Cephalosporins (1st – 5th Generations)": true });
  const [selectedAstNode, setSelectedAstNode] = useState('mrsa');
  const [selectedAmrNode, setSelectedAmrNode] = useState('destruction');

  // Viral, Fungal, Parasitic state
  const [virusGenomeFilter, setVirusGenomeFilter] = useState('ALL');
  const [virusSeverityTier, setVirusSeverityTier] = useState('severe');
  const [fungalMorphFilter, setFungalMorphFilter] = useState('ALL');
  const [fungalSeverityTier, setFungalSeverityTier] = useState('severe');
  const [parasiteCatFilter, setParasiteCatFilter] = useState('ALL');
  const [parasiteSeverityTier, setParasiteSeverityTier] = useState('severe');

  // Syndrome Explorer state
  const [selectedSyndromeId, setSelectedSyndromeId] = useState('cns');

  // PWA Install & Offline status state
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [showInstallModal, setShowInstallModal] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    const handleBeforeInstall = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      setShowInstallModal(true);
    }
  };

  // Filtered Antibiotic Groups
  const filteredAntibioticGroups = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return ANTIBIOTIC_GROUPS;
    return ANTIBIOTIC_GROUPS.map(group => ({
      ...group,
      antibiotics: group.antibiotics.filter(
        ab =>
          ab.name.toLowerCase().includes(q) ||
          ab.trade.toLowerCase().includes(q) ||
          ab.description.toLowerCase().includes(q) ||
          group.group.toLowerCase().includes(q)
      )
    })).filter(group => group.antibiotics.length > 0);
  }, [searchQuery]);

  // Flat Generic vs Trade list
  const flatDrugDirectory = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const all = [];
    ANTIBIOTIC_GROUPS.forEach(g => {
      g.antibiotics.forEach(ab => {
        all.push({ ...ab, group: g.group, moa: g.moa });
      });
    });
    if (!q) return all;
    return all.filter(
      item =>
        item.name.toLowerCase().includes(q) ||
        item.trade.toLowerCase().includes(q) ||
        item.group.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const totalDrugsCount = useMemo(
    () => ANTIBIOTIC_GROUPS.reduce((acc, g) => acc + g.antibiotics.length, 0),
    []
  );

  const toggleGroup = (groupName) => {
    setExpandedGroups(prev => ({ ...prev, [groupName]: !prev[groupName] }));
  };

  const setAllGroups = (open) => {
    const next = {};
    ANTIBIOTIC_GROUPS.forEach(g => { next[g.group] = open; });
    setExpandedGroups(next);
  };

  // Filtered Viruses
  const filteredViruses = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return VIRUS_DATA.filter(v => {
      const matchesGenome =
        virusGenomeFilter === 'ALL' ||
        (virusGenomeFilter === 'DNA' && v.genome.includes('DNA')) ||
        (virusGenomeFilter === 'RNA' && v.genome.includes('RNA'));
      const matchesSearch =
        !q ||
        v.name.toLowerCase().includes(q) ||
        v.family.toLowerCase().includes(q) ||
        v.organs.toLowerCase().includes(q) ||
        v.diseases.toLowerCase().includes(q);
      return matchesGenome && matchesSearch;
    });
  }, [searchQuery, virusGenomeFilter]);

  // Filtered Fungi
  const filteredFungi = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return FUNGAL_DATA.filter(f => {
      const matchesMorph =
        fungalMorphFilter === 'ALL' ||
        f.morphology.toLowerCase().includes(fungalMorphFilter.toLowerCase());
      const matchesSearch =
        !q ||
        f.name.toLowerCase().includes(q) ||
        f.organs.toLowerCase().includes(q) ||
        f.diseases.toLowerCase().includes(q);
      return matchesMorph && matchesSearch;
    });
  }, [searchQuery, fungalMorphFilter]);

  // Filtered Parasites
  const filteredParasites = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return PARASITE_DATA.filter(p => {
      const matchesCat =
        parasiteCatFilter === 'ALL' ||
        p.category.toLowerCase().includes(parasiteCatFilter.toLowerCase());
      const matchesSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.organs.toLowerCase().includes(q) ||
        p.diseases.toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    });
  }, [searchQuery, parasiteCatFilter]);

  const currentSyndrome = useMemo(
    () => SYNDROME_EXPLORER_DATA.find(s => s.id === selectedSyndromeId) || SYNDROME_EXPLORER_DATA[0],
    [selectedSyndromeId]
  );

  const TABS = [
    { id: 'syndrome', label: 'Syndrome Explorer', icon: Stethoscope },
    { id: 'antibiotics', label: '13 Antibiotic Classes', icon: Pill },
    { id: 'trades', label: 'Generic vs. Trade', icon: BookOpen },
    { id: 'clsi', label: 'CLSI 2026 & QC', icon: ShieldCheck },
    { id: 'ast', label: 'AST Workflow', icon: GitBranch },
    { id: 'amr', label: 'AMR Mechanisms', icon: Activity },
    { id: 'viruses', label: 'Human Viruses', icon: Virus },
    { id: 'fungi', label: 'Human Fungi', icon: FlaskConical },
    { id: 'parasites', label: 'Human Parasites', icon: Bug }
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* TOP HEADER */}
      <header className="bg-[#1B365D] text-white shadow-lg border-b-4 border-[#0D9488]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1.5">
                <span className="bg-[#0D9488] text-white text-xs font-bold px-2.5 py-0.5 rounded-full tracking-wider uppercase">
                  LAB READY™ 2026 EDITION
                </span>
                <span className="bg-white/10 text-teal-200 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-teal-400/30">
                  CLSI M100 (36th Ed., 2026) Aligned
                </span>
                <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-0.5 rounded-full ${isOnline ? 'bg-emerald-500/20 text-emerald-200' : 'bg-amber-500/20 text-amber-200'}`}>
                  {isOnline ? <Wifi size={12} /> : <WifiOff size={12} />}
                  {isOnline ? 'Online & Cached' : 'Offline Mode Active'}
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                Infectious Diseases & Diagnostic Microbiology Reference
              </h1>
              <p className="text-slate-200 text-sm mt-1">
                Prepared by <span className="font-semibold text-white">Dr. Elshahat Ahmed El Shahat</span>, Assistant Professor of Microbiology
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={handleInstallClick}
                className="inline-flex items-center gap-2 bg-[#0D9488] hover:bg-teal-600 text-white font-semibold text-sm px-4 py-2.5 rounded-lg shadow transition-colors"
              >
                <Download size={16} />
                Install App (Mobile / Desktop)
              </button>
            </div>
          </div>

          {/* GLOBAL SEARCH BAR */}
          <div className="mt-4 relative max-w-2xl">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search antibiotics, trade names (Augmentin, Rocephin), pathogens, viruses, fungi, or parasites..."
              className="w-full pl-10 pr-10 py-2.5 rounded-lg bg-white text-slate-900 placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488] shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                aria-label="Clear search"
              >
                <X size={16} />
              </button>
            )}
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <nav className="bg-[#142947] border-t border-white/10 overflow-x-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 flex space-x-1 py-2">
            {TABS.map(tab => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                    active
                      ? 'bg-[#0D9488] text-white shadow'
                      : 'text-slate-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon size={15} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </nav>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">

        {/* TAB 1: SYNDROME-TO-ETIOLOGY EXPLORER */}
        {activeTab === 'syndrome' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <h2 className="text-xl font-bold text-[#1B365D] mb-1">Syndrome-to-Etiology Differential Explorer</h2>
              <p className="text-sm text-slate-600 mb-4">
                Select a clinical organ syndrome to compare Bacterial, Viral, Fungal, and Parasitic causes, mandatory diagnostic specimens, red flags, and empiric therapy.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {SYNDROME_EXPLORER_DATA.map(syn => (
                  <button
                    key={syn.id}
                    onClick={() => setSelectedSyndromeId(syn.id)}
                    className={`text-left p-3.5 rounded-lg border-2 transition-all ${
                      selectedSyndromeId === syn.id
                        ? 'border-[#0D9488] bg-teal-50/70 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="font-bold text-sm text-[#1B365D]">{syn.title}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="bg-[#1B365D] text-white px-6 py-4">
                <h3 className="text-lg font-bold">{currentSyndrome.title}</h3>
              </div>
              <div className="p-6 space-y-5">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs font-bold uppercase tracking-wider text-[#0D9488] mb-1">Mandatory Diagnostic Workup</div>
                    <p className="text-sm text-slate-700">{currentSyndrome.workup}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-rose-50 border border-rose-200">
                    <div className="text-xs font-bold uppercase tracking-wider text-rose-700 mb-1">Clinical Red Flags</div>
                    <p className="text-sm text-rose-900">{currentSyndrome.redFlags}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-teal-50 border border-teal-200">
                    <div className="text-xs font-bold uppercase tracking-wider text-teal-800 mb-1">Initial Empiric Regimen</div>
                    <p className="text-sm text-teal-950">{currentSyndrome.empiric}</p>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="border border-blue-200 bg-blue-50/40 rounded-lg p-4">
                    <h4 className="font-bold text-blue-900 text-sm mb-2 flex items-center gap-1.5">
                      <Pill size={15} /> Bacterial Causes
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 list-disc list-inside">
                      {currentSyndrome.etiologies.bacterial.map((item, idx) => <li key={idx}>{item}</li>)}
                    </ul>
                  </div>
                  <div className="border border-purple-200 bg-purple-50/40 rounded-lg p-4">
                    <h4 className="font-bold text-purple-900 text-sm mb-2 flex items-center gap-1.5">
                      <Virus size={15} /> Viral Causes
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 list-disc list-inside">
                      {currentSyndrome.etiologies.viral.map((item, idx) => <li key={idx}>{item}</li>)}
                    </ul>
                  </div>
                  <div className="border border-amber-200 bg-amber-50/40 rounded-lg p-4">
                    <h4 className="font-bold text-amber-900 text-sm mb-2 flex items-center gap-1.5">
                      <FlaskConical size={15} /> Fungal Causes
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 list-disc list-inside">
                      {currentSyndrome.etiologies.fungal.map((item, idx) => <li key={idx}>{item}</li>)}
                    </ul>
                  </div>
                  <div className="border border-emerald-200 bg-emerald-50/40 rounded-lg p-4">
                    <h4 className="font-bold text-emerald-900 text-sm mb-2 flex items-center gap-1.5">
                      <Bug size={15} /> Parasitic Causes
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 list-disc list-inside">
                      {currentSyndrome.etiologies.parasitic.map((item, idx) => <li key={idx}>{item}</li>)}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: 13 ANTIBIOTIC CLASSES */}
        {activeTab === 'antibiotics' && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <div>
                <h2 className="text-lg font-bold text-[#1B365D]">
                  13 Antibiotic Classes ({totalDrugsCount} Core Agents)
                </h2>
                <p className="text-xs text-slate-600">Click any class header to inspect members, trade names, and clinical spectrum.</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setAllGroups(true)}
                  className="px-3 py-1.5 text-xs font-semibold bg-[#1B365D] text-white rounded-lg hover:bg-slate-800"
                >
                  Expand All
                </button>
                <button
                  onClick={() => setAllGroups(false)}
                  className="px-3 py-1.5 text-xs font-semibold bg-slate-200 text-slate-800 rounded-lg hover:bg-slate-300"
                >
                  Collapse All
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {filteredAntibioticGroups.map((group) => {
                const isOpen = !!expandedGroups[group.group];
                return (
                  <div key={group.group} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                    <button
                      onClick={() => toggleGroup(group.group)}
                      className="w-full px-5 py-4 flex items-center justify-between bg-slate-50 hover:bg-teal-50/50 transition-colors text-left"
                    >
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-base sm:text-lg font-bold text-[#1B365D]">{group.group}</span>
                          <span className="text-xs font-semibold bg-[#0D9488]/10 text-[#0D9488] px-2.5 py-0.5 rounded-full">
                            {group.antibiotics.length} agents
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          <span className="font-semibold">MOA:</span> {group.moa} • <span className="font-semibold">Spectrum:</span> {group.spectrum}
                        </p>
                      </div>
                      {isOpen ? <ChevronUp className="text-slate-500 shrink-0" /> : <ChevronDown className="text-slate-500 shrink-0" />}
                    </button>

                    {isOpen && (
                      <div className="p-5 grid sm:grid-cols-2 lg:grid-cols-3 gap-3 border-t border-slate-200">
                        {group.antibiotics.map((ab, idx) => (
                          <div key={idx} className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 hover:border-[#0D9488] transition-colors">
                            <div className="font-bold text-sm text-[#1B365D]">{ab.name}</div>
                            <div className="text-xs font-semibold text-[#0D9488] mt-0.5">Trade: {ab.trade}</div>
                            <p className="text-xs text-slate-600 mt-2 leading-relaxed">{ab.description}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: GENERIC VS TRADE NAMES */}
        {activeTab === 'trades' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-200">
              <h2 className="text-lg font-bold text-[#1B365D]">Generic vs. Clinical Trade Names Directory</h2>
              <p className="text-xs text-slate-600 mt-0.5">
                Use the top search bar to filter instantly by generic name, brand name (e.g., Augmentin, Rocephin, Zosyn), or pharmacologic class.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-[#1B365D] text-white text-xs uppercase">
                    <th className="py-3 px-4">Generic Name</th>
                    <th className="py-3 px-4">Common Trade Name(s)</th>
                    <th className="py-3 px-4">Antibiotic Class</th>
                    <th className="py-3 px-4">Clinical Summary</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {flatDrugDirectory.map((item, idx) => (
                    <tr key={idx} className="hover:bg-teal-50/40">
                      <td className="py-3 px-4 font-bold text-[#1B365D]">{item.name}</td>
                      <td className="py-3 px-4 font-semibold text-[#0D9488]">{item.trade}</td>
                      <td className="py-3 px-4 text-xs text-slate-600">{item.group}</td>
                      <td className="py-3 px-4 text-xs text-slate-600">{item.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: CLSI 2026 BREAKPOINTS & QC */}
        {activeTab === 'clsi' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="bg-[#1B365D] text-white px-6 py-4">
                <h2 className="text-lg font-bold">CLSI M100 (36th Edition, 2026) Key Interpretive Breakpoints</h2>
                <p className="text-xs text-slate-200 mt-0.5">Standardized Disk Diffusion (mm) & MIC (µg/mL) Criteria</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-slate-100 text-[#1B365D] border-b border-slate-200">
                      <th className="py-3 px-4">Organism</th>
                      <th className="py-3 px-4">Antimicrobial Agent</th>
                      <th className="py-3 px-4 text-emerald-700">Susceptible (S)</th>
                      <th className="py-3 px-4 text-amber-700">Intermediate (I)</th>
                      <th className="py-3 px-4 text-rose-700">Resistant (R)</th>
                      <th className="py-3 px-4">CLSI 2026 Laboratory Rule</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {CLSI_2026_BREAKPOINTS.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-bold italic text-[#1B365D]">{row.organism}</td>
                        <td className="py-3 px-4 font-semibold">{row.agent}</td>
                        <td className="py-3 px-4 font-mono text-emerald-700 font-semibold">{row.susceptible}</td>
                        <td className="py-3 px-4 font-mono text-amber-700">{row.intermediate}</td>
                        <td className="py-3 px-4 font-mono text-rose-700 font-semibold">{row.resistant}</td>
                        <td className="py-3 px-4 text-xs text-slate-600">{row.clinicalNote}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <h3 className="text-base font-bold text-[#1B365D] mb-3">Mandatory ATCC Reference Quality Control (QC) Strains</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {CLSI_QC_STRAINS.map((qc, idx) => (
                  <div key={idx} className="p-3.5 rounded-lg border border-teal-200 bg-teal-50/40">
                    <div className="font-bold text-sm text-[#1B365D]">{qc.strain}</div>
                    <p className="text-xs text-slate-600 mt-1">{qc.purpose}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: CLINICAL AST & RESISTANCE WORKFLOW */}
        {activeTab === 'ast' && (
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
            <div>
              <h2 className="text-lg font-bold text-[#1B365D]">Clinical AST & Resistance Detection Workflow (Top-Down)</h2>
              <p className="text-xs text-slate-600 mt-0.5">Click any diagnostic branch below to inspect confirmatory methods and reporting actions.</p>
            </div>

            <div className="flex flex-col items-center space-y-3">
              <div className="px-5 py-2.5 rounded-lg bg-[#1B365D] text-white font-bold text-sm shadow">
                1. Clinical Specimen → Pure Isolate Identification
              </div>
              <ArrowRight className="rotate-90 text-slate-400" size={20} />

              <div className="grid md:grid-cols-3 gap-4 w-full">
                {/* Branch 1: S. aureus */}
                <div
                  onClick={() => setSelectedAstNode('mrsa')}
                  className={`cursor-pointer p-4 rounded-xl border-2 transition-all ${selectedAstNode === 'mrsa' ? 'border-[#0D9488] bg-teal-50/60 shadow' : 'border-slate-200 hover:border-slate-300'}`}
                >
                  <div className="font-bold text-sm text-[#1B365D] mb-2">Branch A: Staphylococcus aureus</div>
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 bg-white rounded border border-slate-200">
                      <span className="font-bold text-rose-700">MRSA Screen:</span> Cefoxitin disk (≤21 mm) / mecA/mecC PCR / PBP2a → Report β-lactam resistant (MRSA).
                    </div>
                    <div className="p-2.5 bg-white rounded border border-slate-200">
                      <span className="font-bold text-amber-700">Vancomycin MIC:</span> Repeat validated broth microdilution MIC:
                      <ul className="list-disc list-inside mt-1 text-slate-600">
                        <li>MIC 4–8 µg/mL = <strong>VISA</strong> (Intermediate)</li>
                        <li>MIC ≥16 µg/mL = <strong>VRSA</strong> (Urgent reference confirmation & public-health alert)</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Branch 2: CoNS */}
                <div
                  onClick={() => setSelectedAstNode('cons')}
                  className={`cursor-pointer p-4 rounded-xl border-2 transition-all ${selectedAstNode === 'cons' ? 'border-[#0D9488] bg-teal-50/60 shadow' : 'border-slate-200 hover:border-slate-300'}`}
                >
                  <div className="font-bold text-sm text-[#1B365D] mb-2">Branch B: Coagulase-Negative Staphylococci</div>
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 bg-white rounded border border-slate-200">
                      <span className="font-bold text-[#1B365D]">Species-Specific Criteria:</span> Apply CLSI 2026 cefoxitin/oxacillin breakpoints (note S. lugdunensis uses S. aureus criteria).
                    </div>
                    <div className="p-2.5 bg-white rounded border border-slate-200">
                      <span className="font-bold text-teal-800">MR-CoNS Clinical Correlation:</span> Interpret prosthetic/catheter infection vs. skin flora contamination (require ≥2 positive blood culture sets).
                    </div>
                  </div>
                </div>

                {/* Branch 3: Enterobacterales */}
                <div
                  onClick={() => setSelectedAstNode('esbl')}
                  className={`cursor-pointer p-4 rounded-xl border-2 transition-all ${selectedAstNode === 'esbl' ? 'border-[#0D9488] bg-teal-50/60 shadow' : 'border-slate-200 hover:border-slate-300'}`}
                >
                  <div className="font-bold text-sm text-[#1B365D] mb-2">Branch C: Enterobacterales (E. coli / Klebsiella)</div>
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 bg-white rounded border border-slate-200">
                      <span className="font-bold text-purple-800">ESBL-E Phenotype / Genotype:</span> Ceftriaxone/ceftazidime non-susceptibility and/or CTX-M/SHV/TEM detection.
                    </div>
                    <div className="p-2.5 bg-white rounded border border-slate-200">
                      <span className="font-bold text-teal-800">Targeted Therapy:</span> Carbapenems (Meropenem/Ertapenem) for invasive bacteremia; nitrofurantoin/fosfomycin for uncomplicated cystitis.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: AMR MECHANISMS PATHWAY */}
        {activeTab === 'amr' && (
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
            <div>
              <h2 className="text-lg font-bold text-[#1B365D]">Antimicrobial Resistance (AMR) Mechanisms Pathway</h2>
              <p className="text-xs text-slate-600 mt-0.5">Six core bacterial resistance strategies leading to therapeutic failure and horizontal gene transfer.</p>
            </div>

            <div className="grid lg:grid-cols-12 gap-4 items-center">
              <div className="lg:col-span-2 p-4 rounded-xl bg-[#1B365D] text-white text-center font-bold text-sm shadow">
                Antimicrobial Reaches Microbe
              </div>

              <div className="lg:col-span-7 grid sm:grid-cols-2 gap-3">
                {[
                  { id: 'destruction', title: '1. Enzymatic Drug Destruction', detail: 'ESBLs, AmpC, KPC, NDM, and OXA carbapenemases hydrolyze the β-lactam ring.' },
                  { id: 'target', title: '2. Target Site Modification', detail: 'mecA encodes low-affinity PBP2a (MRSA); vanA alters D-Ala-D-Ala to D-Ala-D-Lac (VRE).' },
                  { id: 'porin', title: '3. Reduced Entry / Porin Loss', detail: 'Loss or mutation of outer membrane porins (e.g., OprD loss in P. aeruginosa carbapenem resistance).' },
                  { id: 'efflux', title: '4. Active Efflux Pumps', detail: 'Overexpression of RND/MFS efflux pumps (e.g., MexAB-OprM) expels tetracyclines, quinolones, β-lactams.' },
                  { id: 'bypass', title: '5. Metabolic Pathway Bypass', detail: 'Altered DHPS/DHFR enzymes bypass sulfonamide and trimethoprim folate inhibition.' },
                  { id: 'biofilm', title: '6. Biofilm & Persister Cells', detail: 'Extracellular polymeric matrix on catheters/implants slows growth and blocks drug penetration.' }
                ].map(item => (
                  <div
                    key={item.id}
                    onClick={() => setSelectedAmrNode(item.id)}
                    className={`cursor-pointer p-3.5 rounded-lg border-2 transition-all ${selectedAmrNode === item.id ? 'border-[#0D9488] bg-teal-50/70' : 'border-slate-200 bg-slate-50/50'}`}
                  >
                    <div className="font-bold text-xs sm:text-sm text-[#1B365D]">{item.title}</div>
                    <p className="text-xs text-slate-600 mt-1">{item.detail}</p>
                  </div>
                ))}
              </div>

              <div className="lg:col-span-3 space-y-3">
                <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-xs font-semibold">
                  → Survival & Replication Despite Antimicrobial Exposure
                </div>
                <div className="p-4 rounded-xl bg-rose-50 border border-rose-300 text-rose-950 text-xs font-semibold">
                  → Clonal Selection & Horizontal Spread (Plasmids, Transposons, Integrons)
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: HUMAN VIRUSES & ANTIVIRALS */}
        {activeTab === 'viruses' && (
          <div className="space-y-5">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-[#1B365D]">Human Viruses & Severity-Stratified Antiviral Roadmap</h2>
                  <p className="text-xs text-slate-600">Select clinical disease severity tier and filter by DNA or RNA viral genome.</p>
                </div>
                <div className="flex gap-1.5">
                  {['ALL', 'DNA', 'RNA'].map(g => (
                    <button
                      key={g}
                      onClick={() => setVirusGenomeFilter(g)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold ${virusGenomeFilter === g ? 'bg-[#1B365D] text-white' : 'bg-slate-100 text-slate-700'}`}
                    >
                      {g === 'ALL' ? 'All Genomes' : `${g} Viruses`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Severity Roadmap Selector */}
              <div className="grid sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'mild', label: 'Tier 1: Mild / Early Outpatient', color: 'emerald' },
                  { id: 'moderate', label: 'Tier 2: Moderate / Hospital Ward', color: 'amber' },
                  { id: 'severe', label: 'Tier 3: Severe / ICU & Resistant', color: 'rose' }
                ].map(tier => (
                  <button
                    key={tier.id}
                    onClick={() => setVirusSeverityTier(tier.id)}
                    className={`p-3 rounded-lg border-2 text-left text-xs font-bold transition-all ${
                      virusSeverityTier === tier.id
                        ? 'border-[#0D9488] bg-teal-50 text-[#1B365D] shadow-sm'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {filteredViruses.map((v, idx) => (
                <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-bold text-base text-[#1B365D]">{v.name}</h3>
                      <span className="text-xs font-semibold bg-purple-100 text-purple-900 px-2.5 py-0.5 rounded-full shrink-0">
                        {v.genome}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">Family: {v.family}</p>
                    <div className="mt-3 space-y-1.5 text-xs">
                      <p><span className="font-bold text-slate-700">Target Organs:</span> {v.organs}</p>
                      <p><span className="font-bold text-slate-700">Clinical Diseases:</span> {v.diseases}</p>
                    </div>
                  </div>
                  <div className="mt-4 p-3 rounded-lg bg-teal-50/80 border border-teal-200 text-xs">
                    <span className="font-bold text-[#0D9488] uppercase block mb-1">
                      Recommended Regimen ({virusSeverityTier.toUpperCase()}):
                    </span>
                    <span className="text-slate-800 font-medium">{v.treatments[virusSeverityTier]}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 8: HUMAN FUNGI & ANTIFUNGALS */}
        {activeTab === 'fungi' && (
          <div className="space-y-5">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-[#1B365D]">Human Fungal Pathogens & Antifungal Roadmap</h2>
                  <p className="text-xs text-slate-600">Filter by fungal morphology and inspect severity-stratified antifungal regimens.</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {['ALL', 'Yeast', 'Mold', 'Dimorphic'].map(m => (
                    <button
                      key={m}
                      onClick={() => setFungalMorphFilter(m)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold ${fungalMorphFilter === m ? 'bg-[#1B365D] text-white' : 'bg-slate-100 text-slate-700'}`}
                    >
                      {m === 'ALL' ? 'All Morphologies' : m}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'mild', label: 'Tier 1: Superficial / Mild' },
                  { id: 'moderate', label: 'Tier 2: Moderate / Non-Critical' },
                  { id: 'severe', label: 'Tier 3: Severe / Invasive & CNS' }
                ].map(tier => (
                  <button
                    key={tier.id}
                    onClick={() => setFungalSeverityTier(tier.id)}
                    className={`p-3 rounded-lg border-2 text-left text-xs font-bold transition-all ${
                      fungalSeverityTier === tier.id
                        ? 'border-[#0D9488] bg-teal-50 text-[#1B365D] shadow-sm'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {filteredFungi.map((f, idx) => (
                <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-bold text-base italic text-[#1B365D]">{f.name}</h3>
                      <span className="text-xs font-semibold bg-amber-100 text-amber-900 px-2.5 py-0.5 rounded-full shrink-0">
                        {f.morphology}
                      </span>
                    </div>
                    <div className="mt-3 space-y-1.5 text-xs">
                      <p><span className="font-bold text-slate-700">Infected Organs:</span> {f.organs}</p>
                      <p><span className="font-bold text-slate-700">Caused Mycoses:</span> {f.diseases}</p>
                    </div>
                  </div>
                  <div className="mt-4 p-3 rounded-lg bg-teal-50/80 border border-teal-200 text-xs">
                    <span className="font-bold text-[#0D9488] uppercase block mb-1">
                      Antifungal Regimen ({fungalSeverityTier.toUpperCase()}):
                    </span>
                    <span className="text-slate-800 font-medium">{f.treatments[fungalSeverityTier]}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 9: HUMAN PARASITES & ANTIPARASITICS */}
        {activeTab === 'parasites' && (
          <div className="space-y-5">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-[#1B365D]">Human Parasites & Antiparasitic Roadmap</h2>
                  <p className="text-xs text-slate-600">Protozoa, Nematodes, Trematodes, and Cestodes with diagnostic stages and severity roadmaps.</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {['ALL', 'Protozoa', 'Nematode', 'Trematode', 'Cestode'].map(cat => (
                    <button
                      key={cat}
                      onClick={() => setParasiteCatFilter(cat)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold ${parasiteCatFilter === cat ? 'bg-[#1B365D] text-white' : 'bg-slate-100 text-slate-700'}`}
                    >
                      {cat === 'ALL' ? 'All Parasites' : cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'mild', label: 'Tier 1: Uncomplicated / Asymptomatic' },
                  { id: 'moderate', label: 'Tier 2: Moderate / Organ-Localized' },
                  { id: 'severe', label: 'Tier 3: Severe / CNS & Disseminated' }
                ].map(tier => (
                  <button
                    key={tier.id}
                    onClick={() => setParasiteSeverityTier(tier.id)}
                    className={`p-3 rounded-lg border-2 text-left text-xs font-bold transition-all ${
                      parasiteSeverityTier === tier.id
                        ? 'border-[#0D9488] bg-teal-50 text-[#1B365D] shadow-sm'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {filteredParasites.map((p, idx) => (
                <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-bold text-base italic text-[#1B365D]">{p.name}</h3>
                      <span className="text-xs font-semibold bg-emerald-100 text-emerald-900 px-2.5 py-0.5 rounded-full shrink-0">
                        {p.category}
                      </span>
                    </div>
                    <div className="mt-3 space-y-1.5 text-xs">
                      <p><span className="font-bold text-slate-700">Transmission:</span> {p.transmission}</p>
                      <p><span className="font-bold text-slate-700">Diagnostic Stage:</span> {p.diagnosticStage}</p>
                      <p><span className="font-bold text-slate-700">Target Organs:</span> {p.organs}</p>
                      <p><span className="font-bold text-slate-700">Diseases:</span> {p.diseases}</p>
                    </div>
                  </div>
                  <div className="mt-4 p-3 rounded-lg bg-teal-50/80 border border-teal-200 text-xs">
                    <span className="font-bold text-[#0D9488] uppercase block mb-1">
                      Antiparasitic Therapy ({parasiteSeverityTier.toUpperCase()}):
                    </span>
                    <span className="text-slate-800 font-medium">{p.treatments[parasiteSeverityTier]}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* INSTALL INSTRUCTIONS MODAL */}
      {showInstallModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-[#1B365D]">Install LAB READY™ App</h3>
              <button onClick={() => setShowInstallModal(false)} className="text-slate-400 hover:text-slate-700">
                <X size={20} />
              </button>
            </div>
            <div className="space-y-4 text-xs sm:text-sm text-slate-700">
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="font-bold text-[#1B365D] flex items-center gap-1.5 mb-1">
                  <Smartphone size={16} className="text-[#0D9488]" /> iPhone / iPad (Safari)
                </div>
                <p>Tap the <strong>Share (□↑)</strong> button at the bottom of Safari, scroll down, and tap <strong>"Add to Home Screen"</strong>.</p>
              </div>
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="font-bold text-[#1B365D] flex items-center gap-1.5 mb-1">
                  <Smartphone size={16} className="text-[#0D9488]" /> Android (Chrome)
                </div>
                <p>Tap the <strong>⋮ (Three Dots)</strong> menu in the top-right corner and tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</p>
              </div>
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="font-bold text-[#1B365D] flex items-center gap-1.5 mb-1">
                  <Monitor size={16} className="text-[#0D9488]" /> Windows / macOS (Chrome or Edge)
                </div>
                <p>Click the <strong>Install icon</strong> in the right side of the browser address bar to run LAB READY™ as a standalone desktop window.</p>
              </div>
            </div>
            <button
              onClick={() => setShowInstallModal(false)}
              className="mt-5 w-full py-2.5 rounded-lg bg-[#1B365D] text-white font-semibold text-sm hover:bg-slate-800"
            >
              Got It
            </button>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-200 py-5 px-4 sm:px-6 text-center text-xs text-slate-500">
        <p className="font-semibold text-[#1B365D]">
          © 2026 LAB READY™ | Prepared by Dr. Elshahat Ahmed El Shahat, Assistant Professor of Microbiology
        </p>
        <p className="mt-1">
          Aligned with CLSI M100 (36th Edition, 2026). Understand the workflow. Master the concepts. Build laboratory confidence.
        </p>
      </footer>
    </div>
  );
}
